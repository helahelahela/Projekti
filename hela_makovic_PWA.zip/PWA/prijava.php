<?php
include 'connect.php';
define('UPLPATH', 'img/');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="jquery-1.11.0.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="js/form-validation.js"></script> 
    <link rel="stylesheet" href="style.css">
    <title>L'OBS - prijava</title>
</head>
<body>

<h1 id="naslov123">L'OBS</h1>
    <header>
        <nav id="drop" class="clear">
            <a href="index.php">Home</a>
            <a href="kategorija.php?kategorija=politika" id="politika">Politika</a>
            <a href="kategorija.php?kategorija=sport" id="sport">Sport</a>
            <?php
                if (isset($_SESSION['username'])){
                    echo '<a href="unos.php">Unos</a>';
                    echo '<a href="administracija.php">Administracija</a>';
                    echo '<a href="odjava.php style="color: rgb(158, 13, 13);">Odjava</a>';
                }
                else {
                    echo '<a href="prijava.php">Prijava</a>';
                }
            ?>
        </nav>
    </header>

    <main>
        <div class="wrapper">
            <section>
                <form name="prijava" action="" method="POST" enctype="multipart/form-data" class="unos1">
                    <h1>Prijava korisnika</h1>

                    <span id="porukaContent" class="bojaPoruke"></span>
                    <label for="username">Username:</label><br>
                    <input type="text" name="username" id="username"></input><br><br>

                    <span id="porukaPassword" class="bojaPoruke"></span>
                    <label for="password">Lozinka:</label><br>
                    <input type="password" name="password" id="password"></input><br><br>

                    <button type="reset" value="Poništi">Poništi</button>
                    <button type="submit" name="submit" id="submit" value="Submit">Prijavi se</button>
                </form>

                <p id="nemate">Nemate račun? <a href="registracija.php" id="reg">Registrirajte se.</a></p>

                <script type="text/javascript">
                    $(function() {
                        $("form[name='prijava']").validate({
                        rules: {
                            username: {
                                required: true,
                            },
                            password: {
                                required: true,
                            },
                        },
                        messages: {
                            username: {
                                required: "Unesite korisničko ime.",
                            },
                            password: {
                                required: "Potrebno je unijeti lozinku.",
                            },
                        },
                        submitHandler: function(form) {
                            form.submit();
                        }
                        });
                    });
                </script>

                <?php
                    if ($dbc && isset($_POST['submit'])) {
                        $username = $_POST['username'];
                        $lozinka = $_POST['password'];
                        $sql = "SELECT * FROM users WHERE username = ?";
                        $stmt = mysqli_stmt_init($dbc);
            
                        if (mysqli_stmt_prepare($stmt, $sql)) {
                            mysqli_stmt_bind_param($stmt, 's', $username);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_store_result($stmt);
                        }
            
                        mysqli_stmt_bind_result($stmt, $id, $imeKorisnika, $prezimeKorisnika, $usernameKorisnika, $lozinkaKorisnika, $razinaKorisnika);
                        mysqli_stmt_fetch($stmt);
            
                        if (password_verify($lozinka, $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
                            echo "<br><p>Prijava je uspjela.</p>";
                            session_start();
                            $_SESSION['username'] = $username;
                            $_SESSION['level'] = $razinaKorisnika;
                            header('refresh:2; url=index.php');
                        }
                        else {
                            echo "<br><p>Unijeli ste pogrešno korisničko ime ili lozinku.</p>";
                        }
                    }
                ?>
            </section>
        </div>
    </main>
    
    <footer style="margin-top: 270px; padding: 5px;">
        <p>© L'OBS</p>
        <p>Hela Maković, TVZ 2021</p>
    </footer>
</body>
</html>