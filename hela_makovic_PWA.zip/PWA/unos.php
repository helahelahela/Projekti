<?php
include 'connect.php';
define('UPLPATH', 'img/');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquerymysqli_query/3.4.1/jquerymysqli_query.min.js"></script>
    <script type="text/javascript" src="jquerymysqli_query-1.11.0.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquerymysqli_query-validate/1.19.1/jquerymysqli_query.validate.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <script src="js/form-validation.js"></script>
    <title>L'OBS</title>
</head>
<body>
<h1 id="naslov123">L'OBS</h1>
    <header>
        <nav id="drop" class="clear">
            <a href="index.php">Home</a>
            <a href="kategorija.php?kategorija=politika" id="politika">Politika</a>
            <a href="kategorija.php?kategorija=sport" id="sport">Sport</a>
            <?php
                if (isset($_SESSION['username'])){
                    echo '<a href="unos.php">Unos</a>';
                    echo '<a href="administracija.php">Administracija</a>';
                    echo '<a href="odjava.php" style="color: rgb(158, 13, 13);">Odjava</a>';
                }
                else {
                    echo '<a href="prijava.php">Prijava</a>';
                }
            ?>
        </nav>
    </header>

    <main>
        <div class="wrapper">
            <section>
                <form name="unos_clanka" action="skripta.php" method="POST" enctype="multipart/form-data" class="unos">
                    <h1>Unos članka</h1>
                    <span id="porukaTitle" class="bojaPoruke"></span>
                    <label for="naslov">Naslov članka:</label><br>
                    <input type="text" name="naslov" id="naslov"><br><br>

                    <span id="porukaAbout" class="bojaPoruke"></span>
                    <label for="sazetak">Sažetak članka:</label><br>
                    <textarea name="sazetak" id="sazetak" cols="50" rows="3"></textarea><br><br>

                    <span id="porukaContent" class="bojaPoruke"></span>
                    <label for="tekst">Članak:</label><br>
                    <textarea name="tekst" id="tekst" cols="50" rows="12"></textarea><br><br>

                    <span id="porukaKategorija" class="bojaPoruke"></span>
                    <label for="kategorija">Kategorija:</label><br>
                    <select name="kategorija" id="kategorija">
                        <option value="Politika">Politika</option>
                        <option value="Sport">Sport</option>
                    </select><br><br>

                    <span id="porukaSlika" class="bojaPoruke"></span>
                    <label for="image">Dodajte sliku:</label><br>
                    <input type="file" name="image" id="image"><br><br>

                    <label for="pocetna">Prikaz na početnoj stranici:</label>
                    <input type="checkbox" name="pocetna" id="pocetna"><br><br>

                    <button type="reset" value="Poništi">Poništi članak</button>
                    <button type="submit" name="submit" id="submit" value="Submit">Pohrani članak</button>
                </form>

                <script>
                    document.getElementById("submit").onclick = function(event) {
                        var slanjeForme = true;

                        var poljeTitle = document.getElementById("naslov");
                        var title = document.getElementById("naslov").value;
                        if (title.length < 5 || title.length > 30) {
                            slanjeForme = false;
                            poljeTitle.style.border="1px dashed rgb(158, 13, 13)";
                            document.getElementById("porukaTitle").innerHTML="Naslov vjesti mora imati između 5 i 30 znakova!<br>";
                        } else {
                            poljeTitle.style.border="1px solid green";
                            document.getElementById("porukaTitle").innerHTML="";
                        }

                        var poljeAbout = document.getElementById("sazetak");
                        var about = document.getElementById("sazetak").value;
                        if (about.length < 10 || about.length > 100) {
                            slanjeForme = false;
                            poljeAbout.style.border="1px dashed rgb(158, 13, 13)";
                            document.getElementById("porukaAbout").innerHTML="Kratki sadržaj mora imati između 10 i 100 znakova!<br>";
                        } else {
                            poljeAbout.style.border="1px solid green";
                            document.getElementById("porukaAbout").innerHTML="";
                        }

                        var poljeContent = document.getElementById("tekst");
                        var content = document.getElementById("tekst").value;
                        if (content.length == 0) {
                            slanjeForme = false;
                            poljeContent.style.border="1px dashed rgb(158, 13, 13)";
                            document.getElementById("porukaContent").innerHTML="Sadržaj mora biti unesen!<br>"; 
                        } else {
                            poljeContent.style.border="1px solid green";
                            document.getElementById("porukaContent").innerHTML="";
                        }

                        var poljeSlika = document.getElementById("image");
                        var pphoto = document.getElementById("image").value;
                        if (pphoto.length == 0) {
                            slanjeForme = false;
                            poljeSlika.style.border="1px dashed rgb(158, 13, 13)";
                            document.getElementById("porukaSlika").innerHTML="Slika mora biti unesena!<br>";
                        } else {
                            poljeSlika.style.border="1px solid green";
                            document.getElementById("porukaSlika").innerHTML="";
                        }

                        if (slanjeForme != true) {
                            event.preventDefault();
                        }
                    };
                </script>
            </section>
        </div>
    </main>

    <footer>
        <p>© L'OBS</p>
        <p>Hela Maković, TVZ 2021</p>
    </footer>
    
</body>
</html>