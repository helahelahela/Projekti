<?php
include 'connect.php';
define('UPLPATH', 'img/');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" tekst="IE=edge">
    <meta name="viewport" tekst="width=device-width, initial-scale=1.0">
    <meta name="viewport" tekst="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquerymysqli_query/3.4.1/jquerymysqli_query.min.js"></script>
    <script type="text/javascript" src="jquerymysqli_query-1.11.0.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquerymysqli_query-validate/1.19.1/jquerymysqli_query.validate.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>L'OBS - administracija</title>
</head>
<body>
<h1 id="naslov123">L'OBS</h1>
    <header>
        <nav id="drop" class="clear">
            <a href="index.php">Home</a>
            <a href="kategorija.php?kategorija=politika" id="politika">Politika</a>
            <a href="kategorija.php?kategorija=sport" id="sport">Sport</a>
            <?php
                if (isset($_SESSION['username'])){
                    echo '<a href="unos.php">Unos</a>';
                    echo '<a href="administracija.php">Administracija</a>';
                    echo '<a href="odjava.php" style="color: rgb(158, 13, 13);">Odjava</a>';
                }
                else {
                    echo '<a href="prijava.php">Prijava</a>';
                }
            ?>
        </nav>
    </header>

    <main>
        <div class="wrapper">
            <?php

            if (isset($_SESSION['level']) && ($_SESSION['level']) == 1){
                $query = "SELECT * FROM articles";
                $result = mysqli_query($dbc, $query);
                while($row = mysqli_fetch_array($result)) {

                echo '<form enctype="multipart/form-data" action="" method="POST" name="admin" class="admin">
                    <label for="naslov">Naslov vjesti:</label><br>
                    <input type="text" name="naslov" class="form-field-textual" value="'.$row['naslov'].'"><br><br>

                    <label for="sazetak">Sažetak članka (do 50 znakova):</label><br>
                    <textarea name="sazetak" id="" cols="30" rows="10" class="formfield-textual">'.$row['sazetak'].'</textarea><br><br>

                    <label for="tekst">Sadržaj vijesti:</label><br>
                    <textarea name="tekst" id="" cols="30" rows="10" class="formfield-textual">'.$row['tekst'].'</textarea><br><br>

                    <label for="image">Slika:</label><br>
                    <input type="file" class="input-text" id="image" value="'.$row['slika'].'" name="image"/> <br><img src="' . UPLPATH.$row['slika']. '" width=100px class="preview"><br><br>

                    <label for="kategorija">Kategorija vijesti:</label><br>
                    <select name="kategorija" id="" class="form-field-textual" value="'.$row['kategorija'].'">
                        <option value="Politika">Politika</option>
                        <option value="Sport">Sport</option>
                    </select><br><br>

                    <label>Spremiti u arhivu:<br>
                    <input type="checkbox" name="arhiva" id="arhiva"/>
                    Arhiviraj?
                    
                    </label>
                    <input type="hidden" name="id" class="form-field-textual" value="'.$row['id'].'"><br>
                    <button type="reset" value="Poništi">Poništi</button>
                    <button type="submit" name="update" value="Prihvati">Izmjeni</button>
                    <button type="submit" name="delete" value="Izbriši">Izbriši</button>
                    </form>';

                    /* if($row['arhiva'] == 1) {
                    echo '<input type="checkbox" name="arhiva" id="arhiva"/>
                    Arhiviraj?';
                    } else {
                    echo '<input type="checkbox" name="arhiva" id="arhiva"
                    checked/> Arhiviraj?';
                    } */
                }

                if(isset($_POST['delete'])){ 
                    $id = $_POST['id']; 
                    $query = "DELETE FROM articles WHERE id=$id "; 
                    $result = mysqli_query($dbc, $query); 
                }

                if(isset($_POST['update'])){ 
                    $picture = $_FILES['image']['name'];
                    $tempImage = $_FILES['image']['tmp_name'];
                    $naslov = $_POST['naslov']; 
                    $sazetak = $_POST['sazetak']; 
                    $tekst = $_POST['tekst']; 
                    $kategorija = $_POST['kategorija']; 
                    if(isset($_POST['arhiva'])){ 
                        $arhiva = 0; 
                    } else { 
                        $arhiva = 1; 
                    }
                    $id = $_POST['id'];

                    if (move_uploaded_file($_FILES['image']['tmp_name'], __DIR__.'/img/'. $_FILES["image"]['name'])){
                        $query = "UPDATE articles SET naslov='$naslov', sazetak='$sazetak', tekst='$tekst', slika='$picture', kategorija='$kategorija', arhiva='$arhiva' WHERE id=$id"; 
                        $result = mysqli_query($dbc, $query);
                    } else {
                        $query = "UPDATE articles SET naslov='$naslov', sazetak='$sazetak', tekst='$tekst', kategorija='$kategorija', arhiva='$arhiva' WHERE id=$id"; 
                        $result = mysqli_query($dbc, $query);
                    }
                }
                mysqli_close($dbc);
            }
            else {
                echo "<p>Niste administrator, nemate pristup sadržaju ove stranice.</p>";
            }
            ?>
        </div>
    </main>

    <footer>
        <p>© L'OBS</p>
        <p>Hela Maković, TVZ 2021</p>
    </footer>
</body>
</html>