-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 08:35 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) NOT NULL,
  `vrijeme` varchar(32) NOT NULL,
  `naslov` varchar(64) NOT NULL,
  `sazetak` text NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(64) NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `datum`, `vrijeme`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(15, '12 Jun 2021', '00:41', '‘Geostrategic consensus’ on China', 'Joe Biden and Boris Johnson met for the first time on Thursday ahead of the  G7 summit, after much media discourse highlighted the White House’s concerns over Northern Ireland and the president’s scorn for the PM in the past. But as Biden’s US prioritises building an anti-Chinese alliance, analysts say it finds Britain much more likeminded than Germany or France – demonstrating that there was substance beneath the “special relationship” smiles.', 'Biden’s relationship with the British prime minister got off to a rocky start before he entered the White House when he disparaged Johnson as a “physical and emotional clone” of Donald Trump. The populist ex-US president hardly smoothed the path for Johnson’s relationship with any Democratic successor – falsely claiming in 2019 that the UK PM is nicknamed “Britain Trump”.\r\n\r\nNorthern Ireland was expected to be the Biden-Johnson flashpoint. Biden makes a big deal of his (partly) Irish Catholic heritage, so it was unsurprising that the US embassy in London expressed last week “grave concern” over the intensifying UK-EU Northern Ireland dispute. Pundits foresaw Biden pressing Johnson to uphold the Brexit deal as the PM seeks changes to address unionist grievances in the UK province.\r\n\r\nBut after a meeting characterised by effusive expressions of shared priorities – as well as a Biden riff about the importance of the “special relationship\" – journalists asked the PM if the president had expressed alarm about Northern Ireland. Johnson said: “No, he didn’t.”\r\n\r\nWashington ‘obsessed with China’\r\n\r\nIt is not so surprising that Biden avoided Northern Ireland because major US interests are not at stake, suggested Richard Whitman, a professor of politics and international relations at the University of Kent.\r\n\r\n“The UK hasn’t been as good as it could have been at explaining what it’s trying to do – at using public diplomacy to remind Washington that the republican community is not the only group in Northern Ireland with its own priorities and views about how to maintain peace,” he said. Nevertheless, Whitman underlined, “this issue has been subject to a greater degree of magnification that in deserves”.\r\n\r\nBy contrast, the Biden’s focus on China can hardly be magnified enough. His administration emphasised from the start that its international priority is the amplifying geopolitical rivalry with China. Hence Washington’s G7 push for its European partners to rally alongside against Beijing.\r\n\r\n“I don’t think people realise just how important China is in everything that Washington does now,” said Robert Singh, a professor of American politics at Birkbeck, University of London. “It’s become fashionable in some quarters to think that a new Cold War is nonsense and that it’s the preserve of foreign policy hawks; the remnants of neoconservatism. But I don’t buy that. Everybody you talk to in Washington is obsessed with China.”', 'img1.jpg', 'Politika', 1),
(20, '12 Jun 2021', '13:32', 'Italija ide sigurno u polufinale', 'ITALIJA je sinoć na rimskom Olimpicu s 3:0 pobijedila Tursku na otvaranju Eura i fantastičnom partijom nametnula se kao jedan od prvih favorita za zlato.', 'Talijani su me baš impresionirali. Što drugo kazati kad su uputili 24 šuta na gol Turaka, a ovi su njima samo jedan. Obrana im je bila fascinantna, reposjed je bio fenomenalan. Vidi se da su puno radili i uigravali momčad da bi došli do ove razine. U sve četiri faze igre – obrani, napadu te tranziciji u oba smjera – odigrali su izvanredno. Koliko god se trudio pronaći im neku manu, nakon ove utakmice to nije moguće.', 'img4.jpg', 'Sport', 1),
(21, '12 Jun 2021', '13:33', 'Modrić i Ronaldo u Sunovih idealnih 11', 'EUROPSKO prvenstvo koje je jučer u Rimu započelo pobjedom Italije nad Turskom 3:0 vjerojatno će biti posljednje za niz nogometaša. ', 'Među njima će biti i nekih mlađih čije se reprezentacije više neće plasirati na Euro za njihova zenita, ali prvenstveno se radi o onima koji su već u srednjim ili kasnim tridesetima i nije realno očekivati da istu kvalitetu i voljni moment zadrže i za tri godine. Neki od njih već su najavili oproštaj od reprezentacije nakon Eura, a neki i od nogometa.\r\n\r\nMeđu najboljim veteranima su svakako 35-godišnji Luka Modrić i godinu dana stariji Cristiano Ronaldo, a engleski The Sun se potrudio sastaviti idealnu postavu takvih igrača koji nisu tako laka asocijacija kao hrvatska i portugalska zvijezda.', 'img5.jpg', 'Sport', 1),
(22, '12 Jun 2021', '13:35', 'Borba za bodove koji bi mogli značiti prolazak skupine', 'WALES i Švicarska od 15 sati na Europskom prvenstvu igraju prvu utakmicu prvoga kola skupine A na Olimpijskom stadionu u Bakuu.', 'Blagi favorit u ovoj utakmici je Švicarska, no ne treba otpisati ni Velšane koji su na prošlome Europskom prvenstvu u Francuskoj dogurali do polufinala natjecanja. Tri osvojena boda u ovoj utakmici pobjednika bi pogurala prema prolasku skupine jer na Euru u osminu finala idu i najbolje trećeplasirane reprezentacije.', 'img6.jpg', 'Sport', 1),
(32, '13 Jul 2021', '17:33', 'Poražavajući podatak', 'Hrvatska je prvi put izgubila na otvaranju Eura', 'Prvi put u svojoj povijesti engleska nogometna reprezentacija je dobila uvodnu utakmicu na europskim prvenstvima. Nakon devet neuspjeha, \"Gordi Albion\" je pobjedom protiv Hrvatske u susretu 1. kod D skupine upisao prvu pobjedu u uvodnim susretima na europskim prvenstvima.\r\n\r\nDo ove utakmice, Engleska je na europskim prvenstvima nastupila devet puta, pet puta je remizirala, a četiri puta izgubila.\r\n\r\nHrvatska nogometna reprezentacija pak nikada do sada nije bila poražena u prvim susretima na europskim prvenstvima. Vatreni su do sada nastupili na pet europskih prvenstava i u pet uvodnih susreta upisali su četiri pobjede i jedan remi uz razliku pogodaka 6-1.\r\n\r\nEngleska je postala prva momčad od Eura 2012. koja je protiv Hrvatske sačuvala mrežu praznom u grupnoj fazi.', 'img5.jpg', 'sport', 0),
(33, '13 Jul 2021', '17:37', 'Dalić otkrio što se dogodilo', 'Izbornik komentirao situaciju koja je prelomila utakmicu - \'Jedna greška nas je koštala. Vježbali smo to sedam dana\'', 'Na otvaranju Europskog prvenstva 2020. godine reprezentacija Hrvatske je poražena je protiv favorizirane Engleske na Wembleyju s 1:0. Vatreni nisu odigrali loše, stvorili su podosta dobrih prilika, ali izostala je realizacija. Englezi su pak držali jak tempo veći dio utakmice, a pobjedonosni pogodak zabio je Raheem Sterling u 57. minuti nakon vrhunskog prodora Kalvina Phillipsa koji je zavaljao cijelu obranu Hrvatske.\r\n\r\nIzbornik hrvatske nogometne, Zlatko Dalić, odmah je nakon utakmice komentirao nastup svojih nogometaša za HRT.\r\n\r\n\"Čestitke Englezima i našim dečkima. Teška utakmica, teško vrijeme, sparno, ali bilo je kako smo i očekivali. Prvih 20 minuta smo izdržali taj visoki pritisak i nakon toga smo uspostavili kontrolu koliko toliko, dobro smo se držali. Onda taj početak drugog dijela, jedna greška koju smo sedam dana vježbali, da ne izlazimo van iz pozicije stopera, da praznimo prostor i oni su to iskoristili i dali su gol... Ništa sad, idemo dalje, naš cilj je proći grupu, dečke moram samo pohvaliti, odigrali su čvrsto, muška utakmica. Sad imamo dvije utakmice, s Češkom i Škotskom. Popravit ćemo što nije valjalo do ove dvije utakimice\".', 'img8.jpg', 'sport', 0),
(34, '13 Jul 2021', '17:41', 'Ministar Beroš ostao bez kave', '\'Konobarica je odbila nositi masku pa sam odbio biti u tom lokalu\', drugi gost tvrdi: \'Beroš se izderao...\'', '\"Želio sam danas popiti kavu u jednom jadranskom kafiću. No, kako je konobarica i na moju molbu odbila nositi masku, tako sam i ja morao odbiti biti gost u tom lokalu. Odgovorno ponašanje je dužnost svih nas\", napisao je Beroš.\r\n\r\nIako nije napisao je li mu konobarica kazala zašto ne želi nositi zaštitnu masku na licu dok poslužuje goste, moguće je da je tom gestom, kao i mnogi ugostitelji ovih dana, dala do znanja ministru zdravstva da se ne slaže s odlukama Nacionalnog stožera čiji je on član.', 'img9.jpg', 'politika', 1),
(35, '13 Jul 2021', '17:45', 'Milanović prijeti zbog Daytona', '\'Morat ću razgovarati, inače nećemo dati suglasnost na deklaraciju NATO-a. Tretiraju nas kao sitan kusur\'', 'U povodu obilježavanja 30. godišnjice ustrojavanja 63. samostalne gardijske bojne Zbora narodne garde Požega Predsjednik Republike i vrhovni zapovjednik Oružanih snaga Republike Hrvatske Zoran Milanović položio je vijenac i zapalio svijeću kod spomenika poginulim hrvatskim braniteljima. Prije toga obišao je poplavljeno područje u Vidovcima.\r\n\r\n“Vi ste stvoritelji ove države”, poručio je okupljenima i dodao:\r\n\r\n“U komunizmu se obitelj Gordana Grlića Radmana obogatila, dobio je hrvatsko ime Gordan. Neće biti problem s Grlićem, još dogovaramo završnu deklaraciju summita. Neke zemlje ne žele spominjanje Daytonskog sporazuma. Morat ću o tome na summitu razgovarati, inače nećemo dati suglasnost na završnu deklaraciju jer nas se tretira kao sitan kusur. Netko ima problem da se u završnoj deklaraciji NATO-a spominje Daytonski sporazum i tri konstitutivna naroda. Kao da je deklaraciju pisala nevladina udruga iz Sarajeva, ne mislim se vratiti u Zagreb s tim. To pokazuje kakve planove za BiH imaju neki međunarodni krugovi, to preko Hrvatske neće proći. Nisam se mislio time baviti”, rekao je predsjednik.', 'img10.jpg', 'politika', 1),
(36, '13 Jul 2021', '17:49', 'Što se u stvari dogodilo na Wembleyju', 'Više od poraza zabrinjava nešto drugo: \'Upravo tu treba tražiti razloge poraza. No, jedna stvar mi nikako nije jasna\'', 'Pogodak odluke zabio je sjajni brzonogi Raheem Sterling u 57. minuti.\r\n\r\nEnglezi su žestoko pritisnuli na početku i već u 6. minuti odlični mladi Foden je pogodio stativu. Domaćin je imao odličnu priliku i u 9. minuti, no Livaković je sjajno obranio Phillipsov udarac...\r\n\r\nU nastavku prvog dijela gledali smo \"šahovsku partiju\" bez većih prilika. Nažalost, Hrvatska u prvih 45 minuta nije uputila niti jedan udarac u okvir suparničkog gola. U drugom je tek Luka Modrić uputio udarac s nekih 25 metara u okvir gola ali bez opasnosti za Pickforda.\r\n\r\n\"Tu i je problem još veći za nas, što Englezi nisu oduševili ali bila je ovo jedna skroz specifična utakmica na otvaranju natjecanja za Hrvatsku. Dvije odlične reprezentacije, očekivani početak Engleza već u našoj trećini, gdje smo radili pogreške, pokušali na silu izbaciti s loptom, sa pasom, bili nesigurni i čak smo se povukli. Hrvatska već standardno sterilna prema naprijed i tu treba tražiti razloge poraza. Ne znam osim Luke je li Hrvatska uopće imala udarac u okvir gola. S premalo igrača dolazimo u završnicu. Dosta nam se bazira igra preko bokova, puno centaršuteva. Onda bi bilo logično da igramo s jednim klasičnim napadačem\", kazao nam je naš stalni sugovornik nogometnih zbivanja Igor Pamić.', 'img11.jpg', 'sport', 0),
(37, '13 Jul 2021', '17:54', 'Hrvat oduševio navijače', 'Jeste li primijetili što je Livaković napravio tijekom utakmice? Njegov potez izazvao je brojne reakcije', 'Hrvatski vratar Dominik Livaković oduševio je reakcijom u 60. minuti utakmice. Naime, Harry Kane je bio u izvrsnoj prilici, ali je promašio s nekih pet metara da bi se nakon toga zabio u vratnicu.\r\n\r\nS obzirom na onO što se dogodilo u subotu kada se Christian Eriksen srušio usred srčanog zastoja, Livaković je puhao na hladno. Odmah je digao ruku i išao pomoći engleskom napadaču. Njegova reakcija oduševila je korisnike društvenih mreža koji su ga pohvalili zbog tog poteza.\r\n\r\nPodsjetimo, danski reprezentativac i dalje je u bolnici i njegovo je stanje i u nedjelju stabilno, nakon što se u subotu na utakmici protiv Finske srušio poslije čega je oživljavan na terenu, objavio je u nedjelju Danski nogometni savez (DBU).', 'img12.jpg', 'sport', 0),
(38, '13 Jul 2021', '17:57', 'Grlić Radman opleo po Milanoviću', '\'Ovo je huškački napad na mene i obitelj, pitajte njega što će zapravo raditi u Bruxellesu\'', 'Ministar vanjskih i europskih poslova Gordan Grlić Radman uzvratio predsjedniku RH Zoranu Milanoviću prije skorašnjeg NATO summita.\r\n\r\nGrlić Radman obratio se medijima te poručio kako je danas Sv. Ante, dan na koji njegova obitelj slavi imendan njegova oca te da je njegova obitelj zgranuta izjavama na njihov račun. \"Moj otac je poznat kao veliki domoljub, dobročinitelj. Ovo je jedan huškački napad na mene i obitelj, dobio sam puno podrške iz sinjskog kraja odakle Milanović potječe. Ponosan sam na ono što je radio moj otac. Nema smisla i ne bih s upuštao u raspravu oko moga oca. Ponosan sam na časnu ulogu moga oca\", poručio je ministar.\r\n\r\nPitao se čemu predsjednik spominje njegovo ime te je pojasnio i kako ga je dobio. \"Spominjanje imena Gordan. Moj otac je bio vatreni navijač Dinama, dao mi je ime po golmanu, te godine je Dinamo osvojio prvenstvo\", rekao je Grlić Radman pa dodao da Milanovića treba pitati kako je on dobio ime, \"možda je njegov otac navijao za Partizan ili Zvezdu\".', 'img10.jpg', 'politika', 0),
(39, '13 Jul 2021', '17:58', '\'ISKOMPLEKSIRANI LUZER\'', 'HDZ nije ostao dužan Milanoviću: \'Prekaljeni ratnik nastavlja s primitivnom retorikom\'', 'Nakon što je predsjednik RH Zoran Milanović danas komentirao izjavu premijera Plenkovića kako \"pravosuđe nije ničije, a kamoli HDZ-ovo\", i poručio Plenkoviću da je on uveo riječ \"laže\" u vokabular, ubrzo su se oglasili i iz samog HDZ-a.\r\n\r\nU svojoj su objavi na Facebooku napisali da su Titova garda i Partija ostale duboko u Milanoviću te da se ponaša kao iskompleksirani luzer.\r\n\r\nNjihovu objavu prenosimo u cijelosti:\r\n\r\n\'Prononsirani ljevičar i član beogradske Partije\'\r\n\"Odavno više nema Titove garde u kojoj je u Beogradu ušao na vlastiti zahtjev u Partiju, no očito su Titova garda i Partija ostale duboko u Milanoviću!\r\n\r\nNakon što je Milanović kao prononsirani ljevičar i član beogradske Partije ignorirao Dan državnosti i nakon što je propala njegova \"slavna\" inicijativa o uklanjanju proslave pobjedničke Oluje iz Knina, i danas \"prekaljeni ratnik\" nastavlja s primitivnom retorikom i lažima o HDZ-u i predsjedniku Andrej Plenković. I to čini prigodom posjeta svom koalicijskom partneru iz Mosta – Miri Bulju\", napisali su.', 'img10.jpg', 'politika', 0),
(40, '13 Jul 2021', '18:00', 'Stožer: imamo 59 novozaraženih', 'U posljednja 24 sata zabilježeno je 59 novih slučajeva zaraze virusom SARS-CoV-2. Od 25. veljače 2020., kada je zabilježen prvi slučaj zaraze u Hrvatskoj, do danas ukupno su zabilježene 358 563 osobe zaražene novim koronavirusom.\r\n\r\nU samoizolaciji su trenutno 5 783 osobe. Do danas je ukupno testirana 2 078 716 osoba, od toga 4 489 u posljednja 24 sata, javlja Nacionalni stožer.', 'Značajan pad na tjednoj bazi\r\nJučer je zabilježeno 125 novih slučajeva zaraze i devet preminulih osoba od posljedica koronavirusa.\r\n\r\nPrije točno tjedan dana zabilježeno je 157 novih slučajeva, gotovo tri puta više nego danas.', 'img13.jpg', 'politika', 0),
(41, '13 Jun 2021', '18:07', 'Najmlađi gradonačelnik', 'Novi osječki gradonačelnik zatražio je svakodnevne tretmane komaraca', 'Donedavni osječki gradonačelnik Ivica Vrkić predao je dužnost mladom Ivanu Radiću (33) iz HDZ-a koji je izborima postao najmlađi hrvatski gradonačelnik.\r\n\r\n', 'img14.jpg', 'Politika', 0),
(42, '13 Jun 2021', '18:11', 'Nećemo dati suglasnost NATO-u', 'Neke zemlje ne žele spominjanje Daytonskog sporazuma i tri konstitutivna naroda.', 'Vi ste stvoritelji ove države, rekao je predsjednik Zoran Milanović na 30. godišnjici osnutka 63. gardijske bojne ZNG-a u Požegi, piše N1.\r\n\r\n- U komunizmu se obitelj Gordana Grlića Radmana obogatila, dobio je hrvatsko ime Gordan. Neće biti problem s Grlićem, još dogovaramo završnu deklaraciju summita. Neke zemlje ne žele spominjanje Daytonskog sporazuma. Morat ću o tome na summitu razgovarati, inače nećemo dati suglasnost na završnu deklaraciju jer nas se tretira kao sitan kusur. Netko ima problem da se u završnoj deklaraciji NATO-a spominje Daytonski sporazum i tri konstitutivna naroda. Kao da je deklaraciju pisala nevladina udruga iz Sarajeva, ne mislim se vratiti u Zagreb s tim. To pokazuje kakve planove za BiH imaju neki međunarodni krugovi, to preko Hrvatske neće proći. Nisam se mislio time baviti - zaprijetio je. ', 'img15.jpg', 'Politika', 0),
(43, '13 Jun 2021', '18:14', 'Grbin: Okrećemo se građanima', 'Ovo je pitanje opstanka stranke i socijaldemokracije. SDP je danas na raskrižju.', 'Glavni odbor SDP-a u subotu je potvrdio odluku Predsjedništva stranke o raspuštanju organizacija SDP-a u Zagrebu i Slavonskom Brodu te vodstva SDP-a Međimurske županije, a predsjednik SDP-a Peđa Grbin izjavio je da ako žele mijenjati Hrvatsku moraju prvo promijeniti sebe.\r\n\r\n\"Želim da SDP bude stranka koja se doista može baviti time kako će Hrvatsku promijeniti na bolje\", rekao je večeras novinarima Grbin nakon cjelodnevne online sjednice Glavnog odbora SDP-a.\r\n\r\nGrbin i predsjednica Glavnog odbora stranke Marija Lugarić, na online sjednici sudjelovali su iz središnjice SDP-a na Iblerovom trgu. SDP-ove organizacije u Zagrebu i Slavonskom Brodu te vodstva SDP-a Međimurske županije raspušteni su zbog loših izbornih rezultata i pogoršanih unutarstranačkih odnosa.', 'img16.jpg', 'Politika', 0),
(44, '13 Jun 2021', '19:24', 'Vatreni poput pokvarenog sata', 'Vatreni poput pokvarenog sata', 'Dojam nemoći pojačavao je govor tijela, širenje ruku i razgovori između igrača nakon svake pogreške, kao da među sobom traže krivca, što definitivno nije izgledalo dobro, niti ostavljalo dojam sloge, zajedništva.\r\n\r\nI pokvareni sat dva puta na dan pokazuje točno vrijeme, a tako je danas na Wembleyu izgledala hrvatska reprezentacija. Poput pokvarenog sata koji je samo dva puta bio precizan.', 'img18.jpg', 'Sport', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) NOT NULL,
  `prezime` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `lozinka` varchar(255) NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ime`, `prezime`, `username`, `lozinka`, `razina`) VALUES
(2, 'Hela', 'Maković', 'helamakovic', '$2y$10$YFMFw48JqinPpjc.21AXM.xBSO7iIMEMu.QqPAUdg1B.rbt8GqpNG', 1),
(10, 'novi', 'korisnik', 'novikorisnik', '$2y$10$uN8R3fCSZ6IzgEE2wqjr1ex5tusBqtFQ/KIXE/DwPIlqI7QuGKOfO', 0),
(11, 'novi', 'korisnik', 'korisnik2', '$2y$10$NQGz4RrygAA3i3vO6Oi.DOo0MAyFwPOcnVh3QtaT34n7kHI839BCi', 0),
(12, 'Pero', 'Perić', 'pero', '$2y$10$i4uNi8lhlOHT.NDH2QzgLuF2/HkfaGQZsd5QQ6Qq1Wv/AHisx7Bn2', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `articles` ADD FULLTEXT KEY `tekst` (`tekst`);
ALTER TABLE `articles` ADD FULLTEXT KEY `tekst_2` (`tekst`);
ALTER TABLE `articles` ADD FULLTEXT KEY `tekst_3` (`tekst`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
