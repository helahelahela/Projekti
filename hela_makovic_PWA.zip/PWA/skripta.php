<?php
include 'connect.php';
define('UPLPATH', 'img/');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquerymysqli_query/3.4.1/jquerymysqli_query.min.js"></script>
    <script type="text/javascript" src="jquerymysqli_query-1.11.0.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquerymysqli_query-validate/1.19.1/jquerymysqli_query.validate.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>L'OBS</title>
</head>
<body> 
    <h1 id="naslov123">L'OBS</h1>
    <header>
        <nav id="drop" class="clear">
            <a href="index.php">Home</a>
            <a href="kategorija.php?kategorija=politika" id="politika">Politika</a>
            <a href="kategorija.php?kategorija=sport" id="sport">Sport</a>
            <?php
                if (isset($_SESSION['username'])){
                    echo '<a href="unos.php">Unos</a>';
                    echo '<a href="administracija.php">Administracija</a>';
                    echo '<a href="odjava.php" style="color: rgb(158, 13, 13);">Odjava</a>';
                }
                else {
                    echo '<a href="prijava.php">Prijava</a>';
                }
            ?>
        </nav>
    </header>

    <main>
        <?php
            if ($dbc && isset($_POST['submit'])){
                $datum = date("j M Y");
                $sati = date("H:i");
                $naslov = $_POST['naslov'];
                $sazetak = $_POST['sazetak'];
                $tekst = $_POST['tekst'];
                $kategorija = $_POST['kategorija'];
                $image = $_FILES['image']['name'];
                $tempImage = $_FILES['image']['tmp_name'];

                if (move_uploaded_file($_FILES['image']['tmp_name'], __DIR__.'/img/'. $_FILES["image"]['name'])) {
                    echo "Uploaded.<br>";
                } else {
                echo "File not uploaded.<br>";
                }

                if (isset($_POST['pocetna'])){
                    $pocetna = 1;
                } else { 
                    $pocetna = 0; 
                }
                
                $sql = "INSERT INTO articles (datum, vrijeme, naslov, sazetak, tekst, slika, kategorija, arhiva) VALUES ('$datum', '$sati', '$naslov', '$sazetak', '$tekst', '$image', '$kategorija', '$pocetna')";

                $result = mysqli_query($dbc, $sql) or die('Error querying database.');

                if ($result){
                    echo "Članak je unesen. Vraćamo vas na unos.php<br>";
                    header('refresh:3; url=unos.php');
                }
                
            }

            mysqli_close($dbc);
        ?>
    </main>

    <footer>
        <p>© L'OBS</p>
        <p>Hela Maković, TVZ 2021</p>
    </footer>
</body>
</html>
