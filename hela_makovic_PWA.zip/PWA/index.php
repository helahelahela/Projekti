<?php
include 'connect.php';
define('UPLPATH', 'img/');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquerymysqli_query/3.4.1/jquerymysqli_query.min.js"></script>
    <script type="text/javascript" src="jquerymysqli_query-1.11.0.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquerymysqli_query-validate/1.19.1/jquerymysqli_query.validate.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>L'OBS</title>
</head>
<body> 
    <h1 id="naslov123">L'OBS</h1>
    <header>
        <nav id="drop" class="clear">
            <a href="index.php">Home</a>
            <a href="kategorija.php?kategorija=politika" id="politika">Politika</a>
            <a href="kategorija.php?kategorija=sport" id="sport">Sport</a>
            <?php
                if (isset($_SESSION['username'])){
                    echo '<a href="unos.php">Unos</a>';
                    echo '<a href="administracija.php">Administracija</a>';
                    echo '<a href="odjava.php" style="color: rgb(158, 13, 13);">Odjava</a>';
                }
                else {
                    echo '<a href="prijava.php">Prijava</a>';
                }
            ?>
        </nav>
    </header>

    <main>
        <div class="wrapper">
                <h3>Politika</h3>
                <?php
                    $sql = "SELECT * FROM articles WHERE arhiva = 1 AND kategorija = \"politika\" LIMIT 3";
                    $result = mysqli_query($dbc, $sql);
                    while($row = mysqli_fetch_array($result)) {
                        echo "
                            <article>
                                <img src=\"" .UPLPATH.$row['slika']. "\">
                                <div class=\"kvadrat\"><h1><a href='clanak.php?id=" .$row["id"]."'>" .$row['naslov']. "</a></h1></div>
                                <p class=\"vrijeme\">".$row['kategorija']." - ".$row['datum'].", ".$row['vrijeme']."</p>
                            </article>";
        		    }
                ?>

                <h3>Sport</h3>
                <?php
                    $sql = "SELECT * FROM articles WHERE arhiva = 1 AND kategorija = \"sport\" LIMIT 3";
                    $result = mysqli_query($dbc, $sql);
                    while($row = mysqli_fetch_array($result)) {
                        echo "
                            <article>
                                <img src=\"" .UPLPATH.$row['slika']. "\">
                                <div class=\"kvadrat\"><h1><a href='clanak.php?id=" .$row["id"]."'>" .$row['naslov']. "</a></h1></div>
                                <p class=\"vrijeme\">".$row['kategorija']." - ".$row['datum'].", ".$row['vrijeme']."</p>
                            </article>";
        		    }
                ?>
        </div>
    </main>

    <footer>
        <p>© L'OBS</p>
        <p>Hela Maković, TVZ 2021</p>
    </footer>
</body>
</html>