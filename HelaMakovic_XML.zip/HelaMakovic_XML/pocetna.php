<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POČETNA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/jpg" href="slike/favicon1.png"/>
</head>
<body>
<div id="nav">
        <div class="wrapper">
            <ul>
                <li><a href="pocetna.php" class="active">Početna</a></li>
                <li><a href="galerija.php">Galerija</a></li>
                <li><a href="signin.php">Odjava</a></li>
            </ul>
        </div>
    </div>

    <div class="wrapper">
        <div id="main">
            <div id="naslov">
                <h1>Dobro došli!</h1>
            </div>
            <p>Prijavjeni ste pod korisničkim imenom <?php echo $_SESSION['username']?>.</p>
        </div>
    </div>

    <footer>
        <p>Hela Maković, TVZ<br>XML programiranje</p>
    </footer>
</body>
</html>