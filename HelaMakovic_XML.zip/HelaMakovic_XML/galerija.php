<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galerija: Moderna umjetnost</title>
    <script type="text/javascript" src="jquery-1.11.0.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="js/form-validation.js"></script> 
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/jpg" href="slike/favicon1.png"/>
</head>
<body>
    <div id="nav">
        <div class="wrapper">
            <ul>
                <li><a href="pocetna.php">Početna</a></li>
                <li><a href="galerija.php" class="active">Galerija</a></li>
                <li><a href="signin.php">Odjava</a></li>
            </ul>
        </div>
    </div>
    
    <div class="wrapper">
        <div id="main">
            <div id="pozdrav">
                <?php
                    
                    echo "Dobro došli, ". $_SESSION['username'] ."!";

                ?>
            </div>
            <div id="galerija">
                <script>
                    $(document).ready(function() {
                        $.ajax({
                            type: "GET",
                            url: "slike.xml",
                            dataType: "xml",
                            success: parseXml
                            });
                        });

                        function parseXml(xml)
                        {
                        $("#galerija").html("<ul id='content' data-role='listview' data-inset='true'></ul>");
                        $(xml).find("slika").each(function()
                        {
                            $("#content").append("<li><h3>"+$(this).find("naziv").text()+"</h3><img src='"+$(this).find("jpg").text()+"'/><h4>"+$(this).find("slikar").text()+", "+$(this).find("godina").text()+".</h4></li>");
                        });  
                    }
                </script>
            </div>
        </div>
    </div>

    <footer>
        <p>Hela Maković, TVZ<br>XML programiranje</p>
    </footer>
</body>
</html>