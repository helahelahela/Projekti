<?php
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGN IN</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="js/form-validation.js"></script>
    <script type="text/javascript" src="jquery-1.11.0.js"></script>
    <link rel="shortcut icon" type="image/jpg" href="slike/favicon1.png"/>
</head>
<body>
    <div id="nav">
        <div class="wrapper">
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="signin.php" class="active">Sign In</a></li>
                <li><a href="signup.php">Sign Up</a></li>
            </ul>
        </div>
    </div>

    <div class="wrapper">
        <form action="signin.php" method="POST" name="signin1">
            <h4>SIGN IN</h4>
            <label for="username">Korisničko ime:</label>
            <input type="text" id="username" name="username">
            <hr>

            <label for="password">Lozinka:</label>
            <input type="password" id="password" name="password">

            <input type="submit" id="signin" name="signin" value="Sign In">   
        </form>

        <?php
            $username="";
            $password="";
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $ans=$_POST;
                if (empty($ans["username"])) {
                    echo "<p>Korisničko ime nije uneseno.</p>";      
                }
                else if (empty($ans["password"])) {
                    echo "<p>Lozinka nije unesena.</p>";
                }
                else {
                    $username= $ans["username"];
                    $password= $ans["password"];
                    
                    provjera($username,$password);
                }
            }

            function provjera($username, $password) {
                $xml=simplexml_load_file("korisnici.xml");
                foreach ($xml->korisnik as $usr) {
                    $usrn = $usr->username;
                    $usrp = $usr->lozinka;
                    if($usrn==$username) {
                        if($usrp == $password) {
                            echo "<p>Prijavili ste se kao ". $usrn .".<br>
                            <script>
                                setTimeout(function () {
                                    window.location.href = \"galerija.php\";
                                }, 1500);
                            </script></p>";
                            $_SESSION['log'] = true;
                            $_SESSION['username'] = $username;
                            return;
                        }
                        else{
                            echo "<p>Netočna lozinka.</p>";
                            return;
                        }
                    }
                }      
                echo "<p>Korisnik ne postoji.</p>";
                return;
            }
        ?>

        <script>
            $(function() {
                $("form[name='signin1']").validate({
                rules: {
                    username: {
                        required: true,
                    },
                    password: {
                        required: true,
                    },
                },
                messages: {
                    username: {
                        required: "Unesite korisničko ime!",
                    },
                    password: {
                        required: "Unesite lozinku!",
                    },
                },

                submitHandler: function(form) {
                    form.submit();
                }
                });
            });
        </script>
    </div> 
    
    <footer style="margin-top: 280px;">
        <p>Hela Maković, TVZ<br>XML programiranje</p>
    </footer>
</body>
</html>

