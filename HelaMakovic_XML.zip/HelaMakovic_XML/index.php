<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POČETNA</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="image/jpg" href="slike/favicon1.png"/>
</head>
<body>
    <div id="nav">
        <div class="wrapper">
            <ul>
                <li><a href="index.php" class="active">Početna</a></li>
                <li><a href="signin.php">Sign In</a></li>
                <li><a href="signup.php">Sign Up</a></li>
            </ul>
        </div>
    </div>

    <div class="wrapper">
        <div id="main">
            <div id="naslov">
                <h1>Dobro došli!</h1>
            </div>
            <p>Molimo <a href="signin.php">prijavite se</a> kako biste pristupili galeriji.<br>
            Ako nemate postojeći račun, molimo, <a href="signup.php">registrirajte se</a>.<br></p>
        </div>
    </div>

    <footer>
        <p>Hela Maković, TVZ<br>XML programiranje</p>
    </footer>
</body>
</html>