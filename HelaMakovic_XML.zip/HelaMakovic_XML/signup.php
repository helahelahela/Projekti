<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIGN IN</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="js/form-validation.js"></script>
    <script type="password/javascript" src="jquery-1.11.0.js"></script>
    <link rel="shortcut icon" type="image/jpg" href="slike/favicon1.png"/>
</head>
<body>
    <div id="nav">
        <div class="wrapper">
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="signin.php">Sign In</a></li>
                <li><a href="signup.php" class="active">Sign Up</a></li>
            </ul>
        </div>
    </div>

    <div class="wrapper">
        <form action="signup.php" method="POST" name="signup1">
            <h4>SIGN UP</h4>
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email">
            <hr>

            <label for="username2">Korisničko ime:</label>
            <input type="text" id="username2" name="username2">
            <hr>

            <label for="password2">Lozinka:</label>
            <input type="password" id="password2" name="password2">

            <input type="submit" id="signup" name="signup" value="Sign Up"> 
        </form>

        <script>
            $(function() {
                $("form[name='signup1']").validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                    },
                    username2: {
                        required: true,
                    },
                    password2: {
                        required: true,
                    },
                },
                messages: {
                    email: {
                        required: "Unesite e-mail.",
                        email: "E-mail neispravan.",
                    },
                    username2: {
                        required: "Unesite korisničko ime.",
                    },
                    password2: {
                        required: "Unesite lozinku.",
                    },
                },

                submitHandler: function(form) {
                    form.submit();
                }
                });
            });
        </script>

        <?php
            $xml = new DomDocument ("1.0", "UTF-8");
            $xml -> formatOutput = true;
            $xml -> preserveWhiteSpace = false;
            $xml -> load("korisnici.xml");

            if(!$xml) {
                $input = $xml -> createElement("korisnici");
                $xml -> appendChild($input);
            } else {
                $input = $xml -> firstChild;
            }

            if(isset($_POST['signup'])) {
                $email = $_POST['email'];
                $username = $_POST['username2'];
                $password = $_POST['password2'];

                $new = $xml -> createElement("korisnik");
                $input->appendChild($new);
                $email = $xml->createElement("email", $email);
                $new->appendChild($email);
                $username = $xml->createElement("username", $username);
                $new->appendChild($username);
                $password = $xml->createElement("lozinka", $password);
                $new->appendChild($password);

                echo "<center>Uspješno ste se registrirali!<br>Vaši podaci su pohranjeni.</center>";
                echo "<xmp>".$xml->saveXML()."</xmp>";
                $xml->save("korisnici.xml");
            }
        ?>
    </div>  
    
    <footer style="margin-top: 220px;">
        <p>Hela Maković, TVZ<br>XML programiranje</p>
    </footer>
</body>
</html>

